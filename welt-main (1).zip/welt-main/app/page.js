import About from '@/components/About'
import Contact from '@/components/Contact'
import Hero from '@/components/Hero'
import ServiceBundle from '@/components/Services'
import { Button } from '@/components/ui/button'
import React from 'react'

const page = () => {
  return (
    <div>
      <Hero/>
      <ServiceBundle/>
      <About/>
      <Contact/>
    </div>
  )
}

export default page