'use client'
import { motion } from 'framer-motion';
import { TbDeviceVisionPro } from "react-icons/tb";
import { MdReportProblem } from "react-icons/md";
import { MdHistory } from "react-icons/md";

const page = () => {
    return (
        <div className="bg-white py-16 px-4 sm:px-6 lg:px-8">
            <div className="max-w-7xl mx-auto text-center">
                <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
                    <span className="text-green-500">WHO</span> WE ARE
                </h2>
                <p className="mt-4 text-lg leading-6 text-gray-500">
                    The Welt Research Pvt Ltd is a registered private limited company established for research and experimental development on natural sciences and research. We are focused towards exploration and innovations for making the society better.
                    We are keen for working  for the green & sustainable future and for solving the socio-scientific problems for making the society in which no one left behind and a society having “Prosperity and Happiness Together” by working on development of technologies for -
                    Pollution and Climate Change, Agriculture and Food Security, Medical Instrumentations, Big Data Management, Defense Technologies, Computer Modeling and Simulations, AI & ML, IoT, Software Solutions and other scientific and industrial
                </p>
            </div>

            <div className="mt-10 sm:mt-20 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                <motion.div
                    className="flex flex-col items-center text-center p-8 bg-gray-50 rounded-lg shadow-lg"
                    whileHover={{ scale: 1.05 }}
                >
                    <div className="text-green-500 mb-4">
                        <TbDeviceVisionPro size={40} />
                    </div>
                    <h3 className="text-lg font-medium text-green-600">Mission & Vision</h3>
                    <p className="mt-2 text-sm text-gray-600">
                    We are passionate for working towards scientific research and sustainable and efficient innovative solutions for our clients, society, environmental sustainability and global natural wellbeing. We are also keen to develop scientifically and technologically trained and skilled human resources for present and future social and industry needs by integrating academia – research and innovation – industry and society.  We are focus towards technological and scientific advancements of Rural India which is the backbone of our country by creating and providing opportunities to the people by our mission of “ Go Rural with Scientific Minds and Technological Solutions” which we will suppose to be a milestone for the “Atmanirbhar Bharat”.
                    </p>
                </motion.div>

                <motion.div
                    className="flex flex-col items-center text-center p-8 bg-gray-50 rounded-lg shadow-lg"
                    whileHover={{ scale: 1.05 }}
                >
                    <div className="text-blue-500 mb-4">
                        <MdReportProblem size={40} />
                    </div>
                    <h3 className="text-lg font-medium text-blue-600">Problem we are solving</h3>
                    <p className="mt-2 text-sm text-gray-600">
                    We are working for filling the gaps by integrating academia – research and innovation – industry and society for holistic development. Through one side we are providing innovative solutions through scientific research explorations and research capabilities based on our clients need and other side we are keen to promote research and technology innovations in academia to provide solutions for overcoming global issues like climate change and for ensuring sustainable future. We keen provide innovative and technological solutions to our clients by integrating cutting edge technology like advance and big data analysis, AI&ML, IoT, Advance Remote Sensing and Field explorations for overcoming present challenges and giving futuristic solutions.
                    </p>
                </motion.div>

                <motion.div
                    className="flex flex-col items-center text-center p-8 bg-gray-50 rounded-lg shadow-lg"
                    whileHover={{ scale: 1.05 }}
                >
                    <div className="text-red-500 mb-4">
                        <MdHistory size={40} />
                    </div>
                    <h3 className="text-lg font-medium text-red-600">Brief History</h3>
                    <p className="mt-2 text-sm text-gray-600">
                    The Welt Research Pvt Ltd was earlier kniwn as Technovale Prakriti Global innovations Pvt Ltd started in 2022 by experienced scientists, engineers, market professionals and distinguished mentors for Research and Development, technology advancement and technology integration and consultancies based on technology and scientific innvovations in various fields.  In 2024 the company renamed as Welt Research Private limited and presently the company has submitted its various project proposals for fundings. The company presently collaborated with various organization and will soon expand further by 2025.
                    </p>
                </motion.div>
            </div>
        </div>
    );
};
export default page;