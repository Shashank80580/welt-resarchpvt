import React from 'react'
import { Button } from './ui/button'
import Image from 'next/image'
import Link from 'next/link'

const About = () => {
    return (
        <div className='flex flex-col md:flex-row min-h-[60vh] justify-between items-center md:px-64 px-8 mt-3'>
            <div className='hidden md:block md:w-1/2'>
                <Image src='/w2.jpg' width={500} height={300} className='rounded-lg' />
            </div>
            <div className='md:w-1/2 flex flex-col items-center md:items-start'>
                <div className='block md:hidden'>
                    <Image src='/w2.jpg' className='justify-center rounded-lg' width={200} height={100} />
                </div>
                <div className='md:ml-12 lg:ml-5'>
                    <h1 className='font-bold text-[26px] sm:text-[20px] md:text-[40px] md:leading-[40px] mt-5 md:mt-0'>
                    We are <span className='text-green-500'>research-focused</span> innovations for a sustainable, prosperous, and happy society.
                </h1>
                <h3 className='text-[#717171] md:text-[16px] text-[12px] mt-4'>
                The Welt Research Pvt Ltd is a registered private limited company established for research and experimental development on natural sciences and research. We are focused towards exploration and innovations for making the society better...
                </h3>
                <Link href={'/about'}><Button className='rounded-full text-white font-semibold text-[18px] mt-5 md:mt-8 px-[33px] py-[22px] md:px-[53px] md:py-[30px]'>Learn More</Button></Link>
                </div>
            </div>
        </div>
    )
}

export default About