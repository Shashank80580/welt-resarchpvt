'use client'
import React from 'react'
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card'
import { FaCloudSunRain } from "react-icons/fa";
import { MdSecurity } from "react-icons/md";
import { FaBriefcaseMedical } from "react-icons/fa6";
import { ImDatabase } from "react-icons/im";
import { GiSwissArmyKnife } from "react-icons/gi";
import { LuComputer } from "react-icons/lu";

const ServiceBundle = () => {
    const services = [
        {
            title: 'Pollution and Climate Change',
            description: 'Harmful emissions drive climate change, affecting ecosystems, weather patterns, and global temperatures.',
            icon: <FaCloudSunRain size={40} />,
        },
        {
            title: 'Agriculture and Food Security',
            description: 'Innovations ensure sustainable food production, adapting to climate change and feeding the growing population.',
            icon: <MdSecurity size={40} />
        },
        {
            title: 'Medical Instrumentation',
            description: 'Advanced tools enhance diagnostics and treatment, improving patient care and healthcare outcomes.',
            icon: <FaBriefcaseMedical size={40} />,
        },
        {
            title: 'Big Data Management',
            description: 'Efficient data handling optimizes decision-making across industries, powering analytics and insights.',
            icon: <ImDatabase size={40} />,
        },
        {
            title: 'Defence Technologies',
            description: 'Cutting-edge innovations strengthen national security through advanced weaponry, surveillance, and communication systems.',
            icon: <GiSwissArmyKnife size={40} />,
        },
        {
            title: 'Computer Modelling',
            description: 'Simulations predict complex scenarios, aiding in research, development, and problem-solving across various fields.',
            icon: <LuComputer size={40} />,
        },
    ]

    return (
        <div className="px-4 md:px-16 lg:px-32 xl:px-52 py-10 md:py-14 lg:pt-18">
            <div className="text-center">
                <h2 className="text-2xl md:text-3xl font-bold text-gray-800">
                    Our <span className="text-green-600">Services</span>
                </h2>
                <p className="text-base md:text-lg text-gray-500 mt-4">
                    Unlock your business's full potential with our comprehensive suite of services.
                </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mt-8 md:mt-12">
                {services.map((service, index) => (
                    <Card key={index} className="shadow-lg hover:shadow-xl transition-shadow">
                        <CardHeader>
                            <span className="mb-2 text-green-500">{service.icon}</span>  
                            <CardTitle className="text-lg md:text-xl font-semibold">{service.title}</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <CardDescription className="text-sm md:text-base">{service.description}</CardDescription>
                        </CardContent>
                    </Card>
                ))}
            </div>
        </div>
    )
}

export default ServiceBundle

{/* <div class="absolute inset-0 -z-10 h-full w-full bg-white bg-[linear-gradient(to_right,#f0f0f0_1px,transparent_1px),linear-gradient(to_bottom,#f0f0f0_1px,transparent_1px)] bg-[size:6rem_4rem]"><div class="absolute bottom-0 left-0 right-0 top-0 bg-[radial-gradient(circle_800px_at_100%_200px,#d5c5ff,transparent)]"></div></div> */}