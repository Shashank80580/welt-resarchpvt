'use client'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { db } from '@/lib/firebase'
import { addDoc, collection } from 'firebase/firestore'
import React, { useState } from 'react'
import emailjs from '@emailjs/browser';
import { useToast } from './ui/use-toast'

const Contact = () => {
    const { toast } = useToast()
    const [form, setForm] = useState({
        name: "",
        email: "",
        subject: "",
        message: ""
    });
    const handleChange = (e) => {
        setForm({
            ...form,
            [e.target.name]: e.target.value
        });
    };
    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const docRef = await addDoc(collection(db, "contacts"), form);
            emailjs.send(
                "service_9n2uko7",
                "template_jfyhlrs",
                {
                    name: form.name,
                    email: form.email,
                    subject: form.subject,
                    message: form.message
                },
                "pvajCtLRplQtGR2TC"
            );
            toast({
                description: "Your message has been sent.",
            })
            setForm({
                name: "",
                email: "",
                subject: "",
                message: ""
            });
        } catch (err) {
            console.error("Error adding document: ", err);
        }
    };
    return (
        <div className='mt-10'>
            <h1 className='text-center font-bold text-3xl'>
                Need help? Say <span className='underline decoration-8 decoration-green-500'>Hello</span>
            </h1>
            <h1 className='text-center mt-3 text-xl'>
                Feel free to reach to us using the options
            </h1>
            <div className='flex flex-col justify-center items-center min-h-[20vh] mx-auto mt-2 max-w-[800px] p-8'>
                <form className='w-full'>
                    <div className='flex space-x-4 mt-5'>
                        <Input
                            value={form.name}
                            onChange={handleChange}
                            id='name' name='name' placeholder='Name' type='text' className='flex-1' />
                        <Input
                            value={form.email}
                            onChange={handleChange}
                            id="email" name='email' placeholder='Email' type='email' className='flex-1' />
                        <Input
                            value={form.subject}
                            onChange={handleChange}
                            id='subject' name='subject' placeholder='Subject' type='text' className='flex-1' />
                    </div>
                    <div className='mt-5'>
                        <Textarea
                            value={form.message}
                            onChange={handleChange}
                            id="message" name="message" placeholder="Type your message here." className='w-full' />
                    </div>
                    <div className='mt-10 text-center'>
                        <Button onClick={handleSubmit}>Submit</Button>
                    </div>
                </form>
            </div>
        </div>
    )
}

export default Contact;
