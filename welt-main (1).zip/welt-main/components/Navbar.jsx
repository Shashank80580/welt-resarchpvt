'use client'
import Link from 'next/link';
import { Button } from './ui/button';

const Navbar = () => {
    const user = localStorage.getItem('user')
    const handleLogout = () => {
        localStorage.clear('user');
    }
    return (
        <nav className='sticky z-[100] h-14 inset-x-0 top-0 w-full border-b border-gray-200 bg-white/75 backdrop-blur-lg transition-all'>
            <div className='flex h-14 items-center justify-between border-b border-zinc-200 mx-4 md:mx-36'>
                <Link href='/' className='flex items-center gap-2 z-40 font-semibold'>
                    <img src="/w1.png" alt="" className='h-5 w-5 md:h-8 md:w-8'/>
                    <span className='text-green-700 font-bold text-[12px]'>WeltResearch</span>
                </Link>
                <div className='h-full flex items-center space-x-4'>
                        <>
                            {user?'':<Link href={'/signup'}>
                                <Button variant='outline'>Signup</Button>
                            </Link>}
                            {user?<>
                            <Button onClick={handleLogout}>Logout</Button>
                            </>:<>
                            <Link href={'/login'}>
                                <Button>Login</Button>
                            </Link>
                            </>}
                        </>
                </div>
            </div>
    </nav>
    );
};

export default Navbar;
