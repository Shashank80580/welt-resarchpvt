import Image from 'next/image'
import React from 'react'

const Hero = () => {
    return (
        <div className=" bg-white bg-[linear-gradient(to_right,#8080800a_1px,transparent_1px),linear-gradient(to_bottom,#8080800a_1px,transparent_1px)] bg-[size:14px_24px]">
        <div className='flex min-h-[80vh] justify-between items-center md:px-0  lg:px-64 px-4'>
            <div>
                <div className='flex md:hidden justify-center'>
                    <Image src='/w3.jpg' className='mb-8 rounded-lg' width={300} height={200} />
                </div>
                <div className='md:w-[80%]'>
                    <span className='flex items-center gap-2 mb-3'><img src="w1.png" alt="" className='h-10 w-10' /><h1 className='font-semibold text-green-600 text-xl'>Welt Research</h1></span>
                    <h1 className='font-bold text-[26px] md:text-[40px] md:leading-[50px] mt-5 md:mt-0'>Empowering Innovation, Illuminating Solutions</h1>
                <h3 className='text-[#717171] md:text-[18px] lg:text-[24px] md:leading-[30px] text-[12px] mt-8'>Creating sustainable, efficient, and innovative<br className='md:hidden block' /> solutions for a better tomorrow.</h3>
                </div>
            </div>
            <div className='md:block hidden'>
                <Image src='/w3.jpg' width={600} height={400} className='rounded-lg' />
            </div>
        </div>
        </div>
    )
}

export default Hero